import React, { useState, useEffect } from 'react';
import './Search.css';
import '../fonts.css';
import SearchInfo from './SearchInfo';
import Chart from './Chart';
import Table from './Table';
import SearchSub from './searchsub';

function Search({ onStartChange }) { // onStartChange prop 추가
  const [selectedItem, setSelectedItem] = useState(null); // 테이블에서 상세보기 클릭 시 받아온 정보
  const [start, setStart] = useState([]); // SearchSub에서 가져온 정보
  const [infoData, setInfoData] = useState(null); // 처음 검색한 데이터를 저장할 상태

  // 선택된 아이템이 변경될 때마다 콘솔에 출력
  useEffect(() => {
    console.log('table에서 가져온 코드(search):', selectedItem);
  }, [selectedItem]); // selectedItem이 변경될 때만 실행

  // start가 변경될 때마다 콘솔에 값을 출력하고, 부모 컴포넌트에 알림
  useEffect(() => {
    console.log('searchsub에서 search로 가져온 정보:', start);
    onStartChange(start); // start가 변경될 때마다 부모에게 알림
  }, [start, onStartChange]); // start와 onStartChange가 변경될 때만 실행

  // infoData가 변경될 때마다 콘솔에 출력
  useEffect(() => {
    console.log('처음 검색한 데이터:', infoData);
  }, [infoData]); // infoData가 변경될 때만 실행

  // SearchSub에서 전달받은 결과를 처리하는 함수
  const handleResults = (results) => {
    console.log('검색 결과:', results);
    // 검색 결과를 start 상태 변수에 저장
    setStart(results);
  };

  return (
    <div className="Search">
      <div className="checkbox-table">
        <h1>검색 페이지</h1>
        {/* SearchSub 컴포넌트를 추가하고 onResults 콜백을 전달 */}
        <SearchSub 
          onResults={handleResults} 
          setStart={setStart} 
          setInfoData={setInfoData} 
        />
      </div>
      <SearchInfo infoData={infoData} />
      {/* 검색 결과를 전달하여 차트를 렌더링 */}
      <Chart vsData={selectedItem} />
      {/* 검색 결과를 테이블에 전달 */}
      <Table setSelectedItem={setSelectedItem} start={start} />
    </div>
  );
}

export default Search;
